package hlfdev.flutter.flutter_tcc_matus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
